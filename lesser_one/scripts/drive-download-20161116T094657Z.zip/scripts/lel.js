function(context, args)
{
	var caller = context.caller;
	for(var i = 0;i<500;i++){
		#s.accts.xfer_gc_to({to:"jajczak",amount:50})
	}
	
	var l = #s.scripts.lib();
	return ":)";
}
